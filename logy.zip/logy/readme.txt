﻿------------------------------------zh-CN---------------------------------
=== Logy  - 登录/注册的新时代与社交登录和限制登录尝试和Captcha ===
贡献者：kainelabs
标签：登录，社交登录，限制登录尝试，隐藏wordpress工具栏，验证码，注册，丢失密码，重置密码，社交网络，Facebook，谷歌，推特，Instagram，链接，响应，通知，失败的尝试，锁定，身份验证，安全性，小部件，窗体，重定向
捐赠链接：https：//www.paypal.me/KaineLabs
至少要求：3.0
经测试：4.8
稳定的标签：主干
许可证：GPLv2或更高版本
许可证URI：https：//www.gnu.org/licenses/old-licenses/gpl-2.0.html

Logy是最安全，高级，优雅和强大的用户身份验证Wordpress插件。

==说明==
Logy是一个安全的高级登录/注册/重置密码系统，具有优雅的响应式设计和许多强大的功能，如社交登录，限制登录尝试，Captcha等...极其可定制和一系列其他功能由KaineLabs提供。

== __ Logy Page ==
<a href="http://www.kainelabs.com/logy"> http://www.kainelabs.com/logy </a>

== __功能==
<UL>
<li>＃前端登录/注册/重置密码页</ li>
<li>＃社交登录（Facebook，Twitter，Google，Instagram，LinkedIn）</ li>
<li> #Late Login Attempts </ li>
<li>＃Hide普通用户的仪表板和工具栏</ li>
<li>＃创建+ 240个不同的登录表单</ li>
<li>＃创建+140不同的注册表</ li>
<li>＃管理管理员通知</ li>
<li>＃自定义用户通知电子邮件</ li>
<li>登录/注销重定向后的控制（用户/管理员）</ li>
<li>＃高级登录/注册小工具</ li>
<li>＃登录/注册/重置密码短代码</ li>
<li>＃注册角色分配</ li>
<li> #Advanced Captcha System（Google Recaptcha）</ li>
<li>＃自定义所有表单样式</ li>
<li>＃清洁设计</ li>
<li>＃完全响应式设计</ li>
<li>＃启用/禁用注册页面</ li>
<li>＃注册角色分配</ li>
<li>＃和一群UNTOLD特色...... </ li>
</ UL>

== __管理面板功能==
<UL>
<li> #Over +200面板选项</ li>
<li>＃+10选项标签</ li>
<li>＃09配色方案</ li>
<li>＃完全响应式设计</ li>
<li> #Ajaxed Panel（无需刷新）</ li>
</ UL>

== __表单样式功能==
<UL>
<li>＃12输入样式</ li>
<li>＃10按钮样式</ li>
<li>＃02表单标题样式</ li>
<li> #Customize Buttons Text </ li>
<li>＃自定义表单样式</ li>
<li>＃自定义表单标题文本</ li>
<li>＃03输入边框样式（平面，半径，圆角）</ li>
<li>＃03按钮边框样式（平面，半径，圆角）</ li>
<li>＃02输入图标对齐选项（左，右）</ li>
</ UL>

== __额外功能==
<UL>
<li>＃WPML Ready </ li>
<li>＃Fully Translatable </ li>
<li>＃跨浏览器兼容性</ li>
<li>＃详细文档</ li>
<li>＃Well Commented Code </ li>
<li>＃Clean＆Well Organized Code </ li>
<li>＃使用Wordpress最佳实践构建</ li>
<li>＃无需插件</ li>
<li>＃Built Without Frameworks </ li>
<li>＃终身免费更新</ li>
</ UL>

==安装==
<UL>
<li> 1  - 转到WordPress管理面板，然后导航到插件>添加新建>上传。</ li>
<li> 2  - 选择Logy插件zip。</ li>
<li> 3  - 等到安装过程结束。</ li>
<li> 4  - 恭喜你准备好用logy开始新的旅程。</ li>
</ UL>
＃设置Logy页面

安装Logy后，将自动将3个页面添加到您的网站:(登录，注册，忘记密码）

<UL>
<li> 1  -  Go to Appearance> Menus。</ li>
<li> 2  - 将“登录”添加到您的网站导航菜单。</ li>
<li> 3  - 点击“添加到菜单”按钮后。它们将被添加到菜单结构中。</ li>
</ UL>
**注意：**对于登录用户，登录页面将被命名为“Logout”。


==截图==
1. Logy  - 登录表格
2. Logy  - 注册表
3. Logy  - 重置密码形式
4. Logy  - 管理面板 - 登录设置
5. Logy  - 管理员面板 - 社交登录设置
6. Logy  - 管理面板 - 登录样式设置

== Changelog ==
*插件的初始版本

==升级通知==
*插件的初始版本
------------------------------------en-US---------------------------------
=== Logy - The New Era Of Login / Registration With Social Login & Limit Login Attempts & Captcha ===
Contributors: kainelabs
Tags: login, social login, limit login attempts, hide wordpress toolbar, captcha, register, lost password, reset password, social networks, facebook, google, twitter, instagram, linked in, responsive, notifications, failed attempts, lockouts, authentication, security, widget, form, redirection
Donate link: https://www.paypal.me/KaineLabs
Requires at least: 3.0
Tested up to: 4.8
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Logy is The Most Secure , Advanced , Elegant & Powerful User Authentication Wordpress Plugin.

== Description ==
Logy is a Secure & Advanced Login / Registration / Reset Password System with an Elegant Responsive Design and many Powerful features like Social Login, Limit Login Attempts, Captcha and more ... Extremely Customizable and a bunch of other features Provided By KaineLabs.

== __ Logy Page ==
<a href="http://www.kainelabs.com/logy">http://www.kainelabs.com/logy</a>

== __ Features ==
<ul>
<li># Front-End Login/Registration/Reset Password Pages</li>
<li># Social Login ( Facebook, Twitter, Google, Instagram, LinkedIn )</li>
<li># Limit Login Attempts</li>
<li># Hide Dashboard & Toolbar For Normal Users</li>
<li># Create+240 Different Login Form</li>
<li># Create +140 Different Registration Form</li>
<li># Manage Admin Notifications</li>
<li># Customize User Notification Emails</li>
<li># Controle After Login / Logout Redirection ( Users / Admins )</li>
<li># Advanced Login/Registration Widgets</li>
<li># Login/Registration/Reset Password Shortcodes</li>
<li># Registration Role Assignment</li>
<li># Advanced Captcha System ( Google Recaptcha )</li>
<li># Customize All Forms Styling</li>
<li># Clean & Clear Design</li>
<li># Fully Responsive Design</li>
<li># Enable/Disable Registration Page</li>
<li># Registration Role Assignment</li>
<li># AND A BUNCH Of UNTOLD FEATURES …</li>
</ul>

== __ Admin Panel Features ==
<ul>
<li># Over +200 Panel Options</li>
<li># +10 Options Tabs</li>
<li># 09 Color Schemes</li>
<li># Fully Responsive Design</li>
<li># Ajaxed Panel ( No Refresh Required )</li>
</ul>

== __ Forms Styling Features ==
<ul>
<li># 12 Input Styles</li>
<li># 10 Button Styles</li>
<li># 02 Form Headers Styles</li>
<li># Customize Buttons Text</li>
<li># Customize Forms Styling</li>
<li># Customize Forms Header Text</li>
<li># 03 Input Border Styles( Flat, Radius, Rounded )</li>
<li># 03 Buttons Border Styles( Flat, Radius, Rounded )</li>
<li># 02 Input Icons Alignment Options ( Left, Right )</li>
</ul>

== __ Extra Features ==
<ul>
<li># WPML Ready</li>
<li># Fully Translatable</li>
<li># Cross-Browser Compatibility</li>
<li># Detailed Documentation</li>
<li># Well Commented Code</li>
<li># Clean & Well Organized Code</li>
<li># Built Using Wordpress Best Practices</li>
<li># No Plugins Required</li>
<li># Built Without Frameworks</li>
<li># Lifetime Free Updates</li>
</ul>

== Installation ==
<ul>
<li>1 - Go to the WordPress admin panel and then navigate to Plugins > Add New > Upload .</li>
<li>2 - Choose the Logy plugin zip .</li>
<li>3 - Wait untill the installation process ends .</li>
<li>4 - Congratulations you are ready to start a new journey with logy.</li>
</ul>
# Set Up Logy Pages

Once You Install Logy, 3 Pages Will Be added Automatically to your website :  ( Login, Register, Lost Password )

<ul>
<li>1 - Go To Appearance > Menus.</li>
<li>2 - Add "Login" to your website navigation menu.</li>
<li>3 - After you click on the "Add To Menu" Button. they will be added to the Menu Structure.</li>
</ul>
**Note:** The login page will be named "Logout" for logged-in Users.


== Screenshots ==
1. Logy - Login Form
2. Logy - Register Form
3. Logy - Reset Pasword Form
4. Logy - Admin Panel - Login Settings
5. Logy - Admin Panel - Social Login Settings
6. Logy - Admin Panel - Login Styling Settings

== Changelog ==
* Initial release of the plugin

== Upgrade Notice ==
* Initial release of the plugin
